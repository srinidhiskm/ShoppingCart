function val() {
    var x = document.forms["Username"]["Password"].value;
    if (x == null || x == "") {
        alert("Name must be filled out");
        return false;
    }
}