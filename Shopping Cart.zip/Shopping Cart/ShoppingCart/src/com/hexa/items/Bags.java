package com.hexa.items;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Bags
 */
@WebServlet("/Bags")
public class Bags extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Bags() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        HttpSession se=request.getSession();

        se.setAttribute("bags", "fastrack");

        out.println("<html>");
        out.println("<body background='http://il3.picdn.net/shutterstock/videos/3235987/thumb/12.jpg?i10c=img.resize(height:160)'>");
        out.println("<font color='white'>");
        out.println("<h1>You have choosen Fastrack Bags</h1>");
        out.println("<a href='Payment'>Click here to go for payment</a>");
        out.println("</font");
        out.println("</body>");
        out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
