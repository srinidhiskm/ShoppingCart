package com.hexa.items;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Payment
 */
@WebServlet("/Payment")
public class Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        HttpSession se=request.getSession();

        String w=(String) se.getAttribute("watch");
        String s=(String) se.getAttribute("shoes");
        String b=(String) se.getAttribute("bags");

        out.println("<html>");
        out.println("<body background='https://t1.ftcdn.net/jpg/00/70/86/94/240_F_70869411_bxD5PBs6400jQraE0wgVlsLJMRyCM4Vn.jpg'>");
        out.println("<font color='white'>");
        out.println("<h1>Thanks for shopping in ShopRapid.com</h1>");
        out.println("<h3>Keep Visiting</h3>");
        out.println("</body>");
        out.println("</html>");    

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
