package com.hexa.shoprapid;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginDb {
	Connection c=null;
	ResultSet j;
	int count=0;

	public boolean  storeDetails(String user,String pass)
	{
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	    c=DriverManager.getConnection("jdbc:oracle:thin:@172.25.163.114:1521:hyper4","FTP5","Password123");
	    String Query="select * from shoprapid";
		    Statement s=c.createStatement();
		    j =s.executeQuery(Query);
		    while(j.next())
		    {
		    	String u=j.getString(1);
		    	String p=j.getString(2);
		    	//System.out.println(u+"\n"+p);
		    
		    if((user.equals(u))&&(pass.equals(p)))
		    {
		    	count=1;
		    	break;
		    }
		    else
		    {
		    	count=2;
		    }
			}
		    }
			catch(ClassNotFoundException e)
			{
				System.out.println("classnotfound"+e);
			}
			catch(SQLException e)
			{
				System.out.println("Exception"+e);
			}
			if(count==1)
			{
				return true;
			}
			else
			{
				return false;
			}

	   
	}
	

}
