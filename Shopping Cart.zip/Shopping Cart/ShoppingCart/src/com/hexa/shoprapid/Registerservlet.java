package com.hexa.shoprapid;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Registerservlet")
public class Registerservlet extends HttpServlet {
private static final long serialVersionUID = 1L;
public Registerservlet() {
super();
}
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
}
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
int count=0,flag=0,k=0;
String username=request.getParameter("Username");
String password=request.getParameter("Password");
String mobile=request.getParameter("Mobile");
String email=request.getParameter("Email");
Connection c=null;
int l_Username=username.length();
int l_password=password.length();
int l_mobile=mobile.length();
int l_email=email.length();
if(l_Username>3&&l_Username<=10){
request.setAttribute("n_pass_less_than_10",null);
}
else{
k++;
request.setAttribute("n_pass_less_than_10","New password is greater than 10 characters or less than 4 characters");
}
if(l_password>3&&l_password<=10){
for(int i=0;i<l_password;i++){

}

if(count==l_password){
String check=email.substring(l_email-13, l_email);
if("@hexaware.com".equalsIgnoreCase(check)){
for(int i=0;i<l_email;i++){
if(email.charAt(i)=='@'){
flag++;
}
}
if(flag==1){
try{
Class.forName("oracle.jdbc.driver.OracleDriver");
c=DriverManager.getConnection("jdbc:oracle:thin:@172.25.163.114:1521:hyper4", "ftp5", "Password123");
String g="insert into shoprapid values(?,?,?,?)";
PreparedStatement f=c.prepareStatement(g);
f.setString(1, username);
f.setString(2, password);
f.executeUpdate();
}catch(ClassNotFoundException e){
System.out.println(e);
}catch(SQLException e){
System.out.println(e);
}
}
else{
request.setAttribute("@more","@ is more than 1 time");
RequestDispatcher r=request.getRequestDispatcher("Register.jsp");
r.forward(request, response);
}
}else{
request.setAttribute("invalid_em","@hexaware.com not same");
RequestDispatcher r=request.getRequestDispatcher("Register.jsp");
r.forward(request, response);
}
}
else{
request.setAttribute("not_same_pass","not the same password used");
RequestDispatcher r=request.getRequestDispatcher("Register.jsp");
r.forward(request, response);
}
}
else{
request.setAttribute("pass_size","password size of new password and confirm password mismatch");
RequestDispatcher r=request.getRequestDispatcher("Register.jsp");
r.forward(request, response);
}
}
}

