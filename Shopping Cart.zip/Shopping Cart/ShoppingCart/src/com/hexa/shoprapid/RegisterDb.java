package com.hexa.shoprapid;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterDb {
	Connection c=null;
	int i=0;
	public boolean  storeDetails(String uname,String pass,String mobile,String email)
	{
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	    c=DriverManager.getConnection("jdbc:oracle:thin:@172.25.163.114:1521:hyper4","FTP5","Password123");
	    String Query="insert into shoprapid values(?,?,?,?)";
	    PreparedStatement ps = c.prepareStatement(Query);
	    ps.setString(1,uname);
	    ps.setString(2,pass);
	    ps.setString(3,mobile);
	    ps.setString(4,email);
	    i=ps.executeUpdate();
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("class notfound"+e);
		}
		catch(SQLException e)
		{
			System.out.println("Exception"+e);
		}
		if(i==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	   
	}
	

}
