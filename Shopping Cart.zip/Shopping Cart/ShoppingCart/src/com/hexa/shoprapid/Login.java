package com.hexa.shoprapid;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String Uname=request.getParameter("Username");
		String Password=request.getParameter("Password");
	if(Uname.equals("srinidhi")&&Password.equals("srini4201")){
		request.setAttribute("Username", Uname);
		RequestDispatcher rd1=request.getRequestDispatcher("Home.jsp");
		rd1.forward(request, response);
		//out.println("On the page");
		//System.out.println("Welcome");
	}else
	{
		RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
		rd.forward(request, response);
		//out.println("Enter valid username or password");
		//System.out.println("Enter Valid Username or Password");
	}
	}

}